<?php
if ( ! defined( 'ABSPATH' ) ) die( '-1' );
/*
Element Description: ThewriterCustomGrid
*/
 
// Element Class 
class ThewriterCustomGrid extends WPBakeryShortCode {
	public static 	$translate = 'thewriter',
					$meta_options;
	 
	// Element Init
	function __construct() {
		add_action( 'init', array( $this, 'get_meta_options' ) );
		add_action( 'save_post', array( $this, 'save_metabox' ) );
		add_action( 'init', array( $this, 'vc_custom_grid_mapping' ) );
		add_action( 'add_meta_boxes', array( $this, 'metabox_page_setting' ) );
		// add_action( 'admin_enqueue_scripts', array( $this, 'scripts' ) );
		$add_shrtcd = 'add_' . 'shortcode';
		$add_shrtcd( 'vc_custom_grid', array( $this, 'vc_custom_grid_html' ) );
	}
	public function get_meta_options() {
		self::$meta_options = get_option( 'thewriter__post_list_metabox' );
	}

	// Element Mapping
	public function vc_custom_grid_mapping() {
		 
		// Stop all if VC is not enabled
		if ( ! defined( 'WPB_VC_VERSION' ) ) return;
		$translate = self::$translate;

		// Map the block with vc_map()
		vc_map( 
			array(
				'name' 				=> __( 'Posts list', 'thewriter' ),
				'base' 				=> 'vc_custom_grid',
				'content_element' 	=> true,
				'icon' 				=> get_template_directory_uri() .'/vc-addon/img/vc-icon.png',
				'description' 		=> __( 'Show post with VC and one of grid styles', 'thewriter' ),
				'category' 			=> __( 'Thewriter', 'thewriter' ),
				'params' 			=> array(
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> __( 'Select type', 'thewriter' ),
						'param_name' 	=> 'element_type',
						'value' 		=> array(
							__( 'Posts', 'thewriter' ) 		=> 'posts',
							__( 'Pagination', 'thewriter' ) 	=> 'pagination',
						),
						'std' 			=> '',
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> __( 'Total items for addon', 'thewriter' ),
						'param_name' 	=> 'max_items',
						'value' 		=> 10,
						// default value
						// 'param_holder_class' 	=> 'vc_not-for-custom',
						'description' 	=> __( 'Count of display posts in this addon', 'thewriter' ),
						'dependency' 	=> array(
							'element' 		=> 'element_type',
							'value' 		=> 'posts',
						),
					),
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> __( 'Columns numbers (Minimal)', 'thewriter' ),
						'param_name' 		=> 'col_numbers',
						'value' 			=> array(
							__( 'Default', 'thewriter' ) 	=> 'default',
							__( '1 Column', 'thewriter' ) 	=> 'col-sm-12 col-xs-12',
							__( '2 Columns', 'thewriter' ) 	=> 'col-sm-6 col-xs-12',
							__( '3 Columns', 'thewriter' ) 	=> 'col-sm-4 col-xs-12',
							__( '4 Columns', 'thewriter' ) 	=> 'col-sm-3 col-xs-12',
							__( '6 Columns', 'thewriter' ) 	=> 'col-sm-2 col-xs-12',
							__( '12 Columns', 'thewriter' ) 	=> 'col-sm-1 col-xs-12',
						),
						'edit_field_class' 	=> 'vc_col-sm-12',
						'description' 		=> __( 'Select min number of columns.', 'thewriter' ),
						'dependency' 		=> array(
							'element' 			=> 'element_type',
							'value' 			=> 'posts',
						),
					),
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> __( 'Columns numbers (for Tablet)', 'thewriter' ),
						'param_name' 		=> 'col_numbers_md',
						'value' 			=> array(
							__( 'Default', 'thewriter' ) 	=> 'default',
							__( '1 Column', 'thewriter' ) 	=> 'col-md-12',
							__( '2 Columns', 'thewriter' ) 	=> 'col-md-6',
							__( '3 Columns', 'thewriter' ) 	=> 'col-md-4',
							__( '4 Columns', 'thewriter' ) 	=> 'col-md-3',
							__( '6 Columns', 'thewriter' ) 	=> 'col-md-2',
							__( '12 Columns', 'thewriter' ) 	=> 'col-md-1',
						),
						'edit_field_class' 	=> 'vc_col-sm-6',
						'description' 		=> __( 'Select number of columns for screen with width more than 768px.', 'thewriter' ),
						'dependency' 		=> array(
							'element' 			=> 'col_numbers',
							'value_not_equal_to' 			=> 'default',
						),
					),
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> __( 'Columns numbers (for Laptop)', 'thewriter' ),
						'param_name' 		=> 'col_numbers_xl',
						'value' 			=> array(
							__( 'Default', 'thewriter' ) 	=> 'default',
							__( '1 Column', 'thewriter' ) 	=> 'col-xl-12',
							__( '2 Columns', 'thewriter' ) 	=> 'col-xl-6',
							__( '3 Columns', 'thewriter' ) 	=> 'col-xl-4',
							__( '4 Columns', 'thewriter' ) 	=> 'col-xl-3',
							__( '6 Columns', 'thewriter' ) 	=> 'col-xl-2',
							__( '12 Columns', 'thewriter' ) 	=> 'col-xl-1',
						),
						'edit_field_class' 	=> 'vc_col-sm-6',
						'description' 		=> __( 'Select number of columns for screen with width more than 992px.', 'thewriter' ),
						'dependency' 		=> array(
							'element' 			=> 'col_numbers',
							'value_not_equal_to' 			=> 'default',
						),
					),
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> __( 'Columns numbers (for Desktop)', 'thewriter' ),
						'param_name' 		=> 'col_numbers_xxl',
						'value' 			=> array(
							__( 'Default', 'thewriter' ) 	=> 'default',
							__( '1 Column', 'thewriter' ) 	=> 'col-xxl-12',
							__( '2 Columns', 'thewriter' ) 	=> 'col-xxl-6',
							__( '3 Columns', 'thewriter' ) 	=> 'col-xxl-4',
							__( '4 Columns', 'thewriter' ) 	=> 'col-xxl-3',
							__( '6 Columns', 'thewriter' ) 	=> 'col-xxl-2',
							__( '12 Columns', 'thewriter' ) 	=> 'col-xxl-1',
						),
						'edit_field_class' 	=> 'vc_col-sm-6',
						'description' 		=> __( 'Select number of columns for screen with width more than 1200px.', 'thewriter' ),
						'dependency' 		=> array(
							'element' 			=> 'col_numbers',
							'value_not_equal_to' 			=> 'default',
						),
					),
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> __( 'Columns numbers (for Large Screen Displays)', 'thewriter' ),
						'param_name' 		=> 'col_numbers_xxxl',
						'value' 			=> array(
							__( 'Default', 'thewriter' ) 	=> 'default',
							__( '1 Column', 'thewriter' ) 	=> 'col-xxxl-12',
							__( '2 Columns', 'thewriter' ) 	=> 'col-xxxl-6',
							__( '3 Columns', 'thewriter' ) 	=> 'col-xxxl-4',
							__( '4 Columns', 'thewriter' ) 	=> 'col-xxxl-3',
							__( '6 Columns', 'thewriter' ) 	=> 'col-xxxl-2',
							__( '12 Columns', 'thewriter' ) 	=> 'col-xxxl-1',
						),
						'edit_field_class' 	=> 'vc_col-sm-6',
						'description' 		=> __( 'Select number of columns for screen with width more than 1920px.', 'thewriter' ),
						'dependency' 		=> array(
							'element' 			=> 'col_numbers',
							'value_not_equal_to' 			=> 'default',
						),
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> __( 'Margin for column', 'thewriter' ),
						'param_name' 	=> 'col_margin',
						'value' 		=> '',
						// default value
						// 'param_holder_class' 	=> 'vc_not-for-custom',
						'description' 	=> __( 'Set margin for columns.', 'thewriter' ),
						'dependency' 	=> array(
							'element' 		=> 'element_type',
							'value' 		=> 'posts',
						),
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> __( 'Padding for column', 'thewriter' ),
						'param_name' 	=> 'col_padding',
						'value' 		=> '',
						// default value
						// 'param_holder_class' 	=> 'vc_not-for-custom',
						'description' 	=> __( 'Set padding for columns.', 'thewriter' ),
						'dependency' 	=> array(
							'element' 		=> 'element_type',
							'value' 		=> 'posts',
						),
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> __( 'Height for column', 'thewriter' ),
						'param_name' 	=> 'col_height',
						'value' 		=> '',
						// default value
						// 'param_holder_class' 	=> 'vc_not-for-custom',
						'description' 	=> __( 'Set height for columns(Default is 290px)', 'thewriter' ),
						'dependency' 		=> array(
							'element' 			=> 'element_type',
							'value' 			=> 'posts',
						),
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> __( 'Offset', 'thewriter' ),
						'param_name' 	=> 'offset',
						'value' 		=> '',
						// default value
						// 'param_holder_class' 	=> 'vc_not-for-custom',
						'description' 	=> __( 'Set offset of the posts.', 'thewriter' ),
						'dependency' 	=> array(
							'element' 		=> 'element_type',
							'value' 		=> 'posts',
						),
					),
					array(
						'type' 				=> 'dropdown',
						'heading' 			=> __( 'Display Style', 'thewriter' ),
						'param_name' 		=> 'style',
						'value' 			=> array(
							__( 'Show all', 'thewriter' ) 	=> 'all',
							__( 'Pagination', 'thewriter' ) 	=> 'pagination',
						),
						'edit_field_class' 	=> 'vc_col-sm-6',
						'description' 		=> __( 'Select display style for grid.', 'thewriter' ),
						'dependency' 		=> array(
							'element' 			=> 'element_type',
							'value' 			=> 'posts',
						),
					),
					array(
						'type' 				=> 'textfield',
						'heading' 			=> __( 'Items per page', 'thewriter' ),
						'param_name' 		=> 'items_per_page',
						'description' 		=> __( 'Number of items to show per page.', 'thewriter' ),
						'value' 			=> '10',
						'edit_field_class' 	=> 'vc_col-sm-6',
						'dependency' 		=> array(
							'element' 			=> 'style',
							'value' 			=> 'pagination',
						),
					),
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> __( 'Order by', 'thewriter' ),
						'param_name' 	=> 'orderby',
						'value' 		=> array(
							__( 'Date', 'thewriter' ) 				=> 'date',
							__( 'Order by post ID', 'thewriter' ) 	=> 'ID',
							__( 'Random order', 'thewriter' ) 		=> 'rand',
							__( 'Last modified date', 'thewriter' ) 	=> 'modified',
							__( 'Number of comments', 'thewriter' ) 	=> 'comment_count',
						),
						'description' 	=> __( 'Select order type.', 'thewriter' ),
						'group' 		=> __( 'Data Settings', 'thewriter' ),
						// 'param_holder_class' 	=> 'vc_grid-data-type-not-ids',
						'dependency' 		=> array(
							'element' 			=> 'element_type',
							'value' 			=> 'posts',
						),
					),
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> __( 'Sort order', 'thewriter' ),
						'param_name' 	=> 'order',
						'group' 		=> __( 'Data Settings', 'thewriter' ),
						'value' 		=> array(
							__( 'Descending', 'thewriter' ) 	=> 'DESC',
							__( 'Ascending', 'thewriter' ) 	=> 'ASC',
						),
						// 'param_holder_class' 	=> 'vc_grid-data-type-not-ids',
						'description' 	=> __( 'Select sorting order.', 'thewriter' ),
						'dependency' 	=> array(
							'element' 		=> 'element_type',
							'value' 		=> 'posts',
						),
					),
					array(
						'type' 			=> 'checkbox',
						"admin_label" 	=> true,
						'heading' 		=> __( 'Post format exclude', 'thewriter' ),
						'param_name' 	=> 'post_format_exclude',
						'group' 		=> __( 'Data Settings', 'thewriter' ),
						'value' 		=> array(
							__( 'Gallery', 'thewriter' ) 	=> 'post-format-gallery',
							__( 'Link', 'thewriter' ) 		=> 'post-format-link',
							__( 'Image', 'thewriter' ) 		=> 'post-format-image',
							__( 'Quote', 'thewriter' ) 		=> 'post-format-quote',
							__( 'Video', 'thewriter' ) 		=> 'post-format-video',
							__( 'Audio', 'thewriter' ) 		=> 'post-format-audio',
							__( 'Aside', 'thewriter' ) 		=> 'post-format-aside',
							__( 'Chat', 'thewriter' ) 		=> 'post-format-chat',
							__( 'Status', 'thewriter' ) 		=> 'post-format-status',
							__( 'Standard', 'thewriter' ) 	=> 'post-format-standard'
						),
						'settings' 		=> array(
							'multiple' 		=> true,
						),
						'std' 			=> '',
						'description' 	=> __( 'Exclude one or multiple posts format.', 'thewriter' ),
					),
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> __( 'Post show template', 'thewriter' ),
						'param_name' 	=> 'custom_grid',
						'value' 		=> array(
							__( 'Standard', 'thewriter' ) 	=> 'standard',
							__( 'Grid', 'thewriter' ) 		=> 'grid',
							__( 'Masonry', 'thewriter' ) 	=> 'masonry',
							__( 'Blocks', 'thewriter' ) 		=> 'blocks',
							__( 'Boxed', 'thewriter' ) 		=> 'boxed',
						),
						'std' 			=> '',
						'description' 	=> __( 'Select template for posts.', 'thewriter' ),
						'group' 		=> __( 'Item Design', 'thewriter' ),
						'dependency' 	=> array(
							'element' 		=> 'element_type',
							'value' 		=> 'posts',
						),
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> __( 'Extra class name', 'thewriter' ),
						'param_name' 	=> 'el_class',
						'description' 	=> __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'thewriter' ),
						'dependency' 	=> array(
							'element' 		=> 'element_type',
							'value' 		=> 'posts',
						),
					),
					array(
						'type' 			=> 'css_editor',
						'heading' 		=> __( 'CSS box', 'thewriter' ),
						'param_name' 	=> 'css',
						'group' 		=> __( 'Design Options', 'thewriter' ),
						'dependency' 	=> array(
							'element' 		=> 'element_type',
							'value' 		=> 'posts',
						),
					),

				)
			)
		);
		
	}
	
	// Element HTML
	public function vc_custom_grid_html( $atts ) {

		$theme_dir = get_template_directory();
		$default_atts = array(
			'element_type' 			=> '',
			'post_type' 			=> 'post',
			'max_items' 			=> '10',
			'style' 				=> 'all',
			'items_per_page' 		=> '10',
			'orderby' 				=> 'date',
			'order' 				=> 'DESC',
			'custom_grid' 			=> 'standard',
			'post_format_exclude' 	=> '',
			'ignore_sticky' 		=> 'Yes',
			'offset' 				=> '0',
			'col_margin' 			=> '',
			'col_padding' 			=> '',
			'col_height' 			=> '',
			'col_numbers' 			=> 'default',
			'col_numbers_md' 		=> false,
			'col_numbers_xl' 		=> false,
			'col_numbers_xxl' 		=> false,
			'col_numbers_xxxl' 		=> false,
		);
		$atts = shortcode_atts( $default_atts, $atts );
		ob_start();
		include $theme_dir .'/plugins/js_composer/templates/paste_the_posts.php';
		$output = ob_get_contents();
		ob_get_clean();

		return $output;

	}
	public function save_metabox( $post_id ) {

		// Verify this came from the our screen and with proper authorization,
		// because save_post can be triggered at other times
		// if ( !wp_verify_nonce( $_POST['_wpnonce'], plugin_basename(__FILE__) ) ) return $post_id;

		// Verify if this is an auto save routine. If it is our form has not been submitted, so we dont want
		// to do anything
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		// Check if it is not have post type
		if ( ! isset( $_POST['post_type'] ) ) {
			return $post_id;
		}
		// Check permissions to edit pages and/or posts
		// if( 'page' == $_POST['post_type'] || 'post' == $_POST['post_type'] ) {
		if ( $_POST['post_type'] == 'page' && isset( $_POST['thewriter__post_list_metabox'] ) ) {
			// if ( !current_user_can( 'edit_page', $post_id ) || !current_user_can( 'edit_post', $post_id ) )
			if ( ! current_user_can( 'edit_page', $post_id ) )
				return $post_id;

			if ( isset( $_POST['thewriter__post_list_metabox'] ) && isset( $_POST['thewriter__post_list_metabox']['items_per_page'] ) ) {

				$options = $old_options = array();
				$old_options 		= self::$meta_options;
				$options[$post_id] 	= $_POST['thewriter__post_list_metabox'];

				if ( is_array( $old_options ) ) {
					$new_options = array_replace( $old_options, $options );
				} else {
					$new_options = $options;
				}

				update_option( 'thewriter__post_list_metabox', $new_options );
			}
		}

		return $post_id;
	}
	public function metabox_page_setting() {
		add_meta_box(
			'thewriter__post_list_metabox',
			esc_html__( "Thewriter Post List Settings", 'thewriter' ),
			array( $this, 'metabox_page_setting__html' ),
			'page',
			'normal',
			'high'
		);
	}
	public function metabox_page_setting__html() {
		$options 	= self::$meta_options;
		$post_id 	= get_the_ID();
		$translate 	= self::$translate;
		?>
		<div class="aero_addons_metabox__wrap">
			<!-- items per page -->
			<div class="thewriter__post_list_metabox__option">
				<label><?php echo __('Items Per Page', 'thewriter'); ?></label><br />
				<input type="number" name="thewriter__post_list_metabox[items_per_page]" value="<?php echo ( isset( $options[ $post_id ]['items_per_page'] ) ? $options[ $post_id ]['items_per_page'] : '10' ) ?>" />
			</div>
			<!-- items per page with max offset -->
			<div class="thewriter__post_list_metabox__option">
				<label><?php echo __('Items Per Page with max offset', 'thewriter'); ?></label><br />
				<input type="number" name="thewriter__post_list_metabox[items_per_page_with_offset]" value="<?php echo ( isset( $options[ $post_id ]['items_per_page_with_offset'] ) ? $options[ $post_id ]['items_per_page_with_offset'] : '10' ) ?>" />
			</div>
		</div>
		<?php
	}

	// public static function scripts() {
	// 	wp_enqueue_script( 'thewriter__post_list_metabox__js', get_template_directory_uri() .'/vc-addon/js/main.js' );
	// }

}// End Element Class

// Element Class Init
new ThewriterCustomGrid();